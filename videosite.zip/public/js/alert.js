$(document).ready(function(){
    $('#normalselect').attr("disabled", true);
    $('.alert-block').fadeIn(1000);
    setTimeout(function(){$('.alert-block').fadeOut(1000);},4000);

    $('#superselect').change(function(){
        var data = $(this).val();
        $.ajax({
            url:'/admin/edit/findnormal',
            data:{data:data},
            type:'get',
            dataType: 'json',
            success:function(data){
                console.log(data);
                if(data != 'no'){
                    $('#normalselect').attr("disabled", false);
                    $('#normalselect').empty();
                    $('#normalselect').append(`
                        <option value="">Please select</option>
                    `);
                    $('#normalselect option').text('Please select');
                    for(var i=0;i<data.length;i++){
                        $('#normalselect').append(`
                            <option value="${data[i].id}">${data[i].normal_category_name}</option>
                        `);
                    }                    
                }else{
                    $('#normalselect').empty();
                    $('#normalselect').append(`
                        <option value="">Please select</option>
                    `);
                    // $('#normalselect').attr("disabled", true);
                }
            }
        })
    })
})