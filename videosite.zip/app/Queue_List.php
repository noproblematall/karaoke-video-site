<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Queue_List extends Model
{
    protected $fillable = [
        'user_id',
        'title',
        'artist',
        'code',
        'cdgpath',
        'mp3path',
        'is_admin'
    ];
}
