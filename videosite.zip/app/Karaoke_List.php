<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Karaoke_List extends Model
{
    protected $table = 'karaoke_lists';
    protected $fillable = [
        'normal_category_id',
        'super_category_id',
        'title',
        'artist',
        'code',
        'cdgpath',
        'mp3path',
    ];
}
