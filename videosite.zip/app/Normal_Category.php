<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Normal_Category extends Model
{
    protected $table = "normal_categorys";
    protected $fillable = [
        'super_category_id',
        'normal_category_name'
    ];

    public function super_category()
    {
        return belongsTo('App\Super_Category');
    }
}
