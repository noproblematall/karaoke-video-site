  <?php $__env->startSection('title'); ?>
      <title>Messages</title>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>    
        <div class="row">
          <div class="col-md-6">
            <div class="tile">
              <h3 class="tile-title">Messages</h3>
              <div class="embed-responsive embed-responsive-16by9">
                <canvas class="embed-responsive-item" id="lineChartDemo"></canvas>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="tile">
              <h3 class="tile-title">Support Requests</h3>
              <div class="embed-responsive embed-responsive-16by9">
                <canvas class="embed-responsive-item" id="pieChartDemo"></canvas>
              </div>
            </div>
          </div>
        </div>
    </main>
  <?php $__env->stopSection(); ?>
  

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>