  <?php $__env->startSection('title'); ?>
      <title>Karaoke Player</title>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content-title'); ?>
      <h1><i class="fa fa-dashboard"></i> Karaoke Player</h1>
      <p>You can use this karaoke player</p>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('breadcrumb'); ?>
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
      <li class="breadcrumb-item">Player</li>
      <li class="breadcrumb-item">Karaoke Player</li>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>    
        <div class="row">
          <div class="col-md-6">
            <div class="tile">
              <h3 class="tile-title">Play Sales</h3>
              <div class="embed-responsive embed-responsive-16by9">
                <canvas class="embed-responsive-item" id="lineChartDemo"></canvas>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="tile">
              <h3 class="tile-title">Support Requests</h3>
              <div class="embed-responsive embed-responsive-16by9">
                <canvas class="embed-responsive-item" id="pieChartDemo"></canvas>
              </div>
            </div>
          </div>
        </div>
    </main>
  <?php $__env->stopSection(); ?>
  

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>