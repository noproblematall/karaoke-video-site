  <?php $__env->startSection('title'); ?>
      <title>Song Edit</title>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content-title'); ?>
      <h1><i class="fa fa-edit"></i> Karaoke Edit</h1>
      <p>You can use upload your karaokes</p>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('alert'); ?>
    <?php if(Session::get('success')): ?>
    
    <div class="alert alert-success alert-block" style="margin:0;display:none;">
        <button type="button" class="close" data-dismiss="alert">&nbsp;×</button>
        <strong><?php echo e(Session::get('success')); ?></strong>
    </div>
    <?php endif; ?>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('breadcrumb'); ?>
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
      <li class="breadcrumb-item">Edit</li>
      <li class="breadcrumb-item">Karaoke Edit</li>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>    
        <div class="row">
          <div class="col-lg-6 col-md-12">
            <div class="tile">
              <h3 class="tile-title">Karaoke Upload</h3>
            <form name="importform" action="<?php echo e(route('admin.edit.karaoke.store')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label class="control-label" for="title">Title</label>
                    <input class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" id="title" name="title" type="text" placeholder="Enter Song Title" value="<?php echo e(old('title')); ?>">
                    <?php if($errors->has('title')): ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('title')); ?></strong>
                      </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                    <label class="control-label" for="artist">Artist</label>
                    <input class="form-control<?php echo e($errors->has('artist') ? ' is-invalid' : ''); ?>" id="artist" name="artist" type="text" placeholder="Enter Artist" value="<?php echo e(old('artist')); ?>">
                    <?php if($errors->has('artist')): ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('artist')); ?></strong>
                      </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                      <label class="control-label" for="code">Code</label>
                      <input class="form-control<?php echo e($errors->has('code') ? ' is-invalid' : ''); ?>" id="code" name="code" type="text" placeholder="Enter Code" value="<?php echo e(old('code')); ?>">
                      <?php if($errors->has('code')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('code')); ?></strong>
                        </span>
                      <?php endif; ?>
                  </div>
                  <div class="form-group file1">
                      <label class="control-label">CDG file</label>
                      <input class="form-control<?php echo e($errors->has('cdgfile') ? ' is-invalid' : ''); ?>" id="cdgfile" name="cdgfile" type="file">
                      <?php if($errors->has('cdgfile')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('cdgfile')); ?></strong>
                        </span>
                      <?php endif; ?>
                  </div>
                  <div class="form-group file2">
                      <label class="control-label">MP3 file</label>
                      <input class="form-control<?php echo e($errors->has('mp3file') ? ' is-invalid' : ''); ?>" id="mp3file" name="mp3file" type="file">
                      <?php if($errors->has('mp3file')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('mp3file')); ?></strong>
                        </span>
                      <?php endif; ?>
                      <?php //dd($errors);?>
                  </div>
                  <div class="form-group">
                      <label for="superselect">Super Category</label>
                      <select class="form-control<?php echo e($errors->has('superselect') ? ' is-invalid' : ''); ?>" id="superselect" name="superselect">
                        <option value="">Please select</option>
                        <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <option value="<?php echo e($result->id); ?>"><?php echo e($result->super_category_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <option value="">Please register Super category !</option>
                        <?php endif; ?>
                        </select>
                        <?php if($errors->has('superselect')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('superselect')); ?></strong>
                          </span>
                        <?php endif; ?>
                  </div>
                  <div class="form-group">
                      <label for="normalselect">Normal Category</label>
                      <select class="form-control" id="normalselect" name="normalselect">
                        <option>First, Please select Super Category</option>
                        
                      </select>
                  </div>
                  <p class="bs-component">
                      <button class="btn btn-primary btn-lg btn-block" type="submit" id="song-import">Upload</button>
                  </p>
              </form>
            </div>
          </div>
          <div class="col-lg-6 col-md-12">
            <div class="tile">
              <h3 class="tile-title">Karaoke List</h3>
              <div class="embed-responsive embed-responsive-16by9">
                <canvas class="embed-responsive-item" id="pieChartDemo"></canvas>
              </div>
            </div>
          </div>
        </div>
    </main>
  <?php $__env->stopSection(); ?>
  

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>