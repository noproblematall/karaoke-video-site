  <?php $__env->startSection('title'); ?>
      <title>Settings</title>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content-title'); ?>
      <h1><i class="fa fa-cog"></i> Seetings</h1>
      <p>You can set your profile and categories</p>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('alert'); ?>
    <?php if(Session::get('success')): ?>
    
    <div class="alert alert-success alert-block" style="margin:0;display:none;">
        <button type="button" class="close" data-dismiss="alert">&nbsp;×</button>
        <strong><?php echo e(Session::get('success')); ?></strong>
    </div>
    <?php endif; ?>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('breadcrumb'); ?>
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
      <li class="breadcrumb-item">Settings</li>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
        <div class="row">
          <div class="col-md-6">
            <div class="row">
              <div class="col-md-12">
                <div class="tile">
                    <h3 class="tile-title">Super Category Upload</h3>
                    <form action="<?php echo e(route('admin.settings.superstore')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="control-label" for="super">Super Category</label>
                            <input class="form-control<?php echo e($errors->has('super') ? ' is-invalid' : ''); ?>" id="super" name="super" type="text" placeholder="Enter Super Category" value="<?php echo e(old('super')); ?>" autocomplete="off" required>
                            <?php if($errors->has('super')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('super')); ?></strong>
                                </span>
                            <?php endif; ?>
                            </div>
                        <p class="bs-component">
                            <button class="btn btn-primary btn-lg btn-block" type="submit" id="super-import">Save</button>
                        </p>
                    </form>                      
                </div>
              </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="tile">
                        <h3 class="tile-title">Normal Category Upload</h3>
                        <form action="<?php echo e(route('admin.settings.normalstore')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="supersetting">Super Category</label>
                                <select class="form-control<?php echo e($errors->has('supersetting') ? ' is-invalid' : ''); ?>" id="supersetting" name="supersetting">
                                  <option value="">Please select</option>
                                  <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($result->id); ?>"><?php echo e($result->super_category_name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option value="">There is no item !</option>
                                  <?php endif; ?>
                                </select>
                                <?php if($errors->has('supersetting')): ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('supersetting')); ?></strong>
                                  </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="normal">Normal Category</label>
                            <input class="form-control<?php echo e($errors->has('normal') ? ' is-invalid' : ''); ?>" autocomplete="off" id="normal" name="normal" type="text" placeholder="Enter Super Category" value="<?php echo e(old('normal')); ?>" required>
                                <?php if($errors->has('normal')): ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('normal')); ?></strong>
                                  </span>
                                <?php endif; ?>
                            </div>
                            <p class="bs-component">
                                <button class="btn btn-primary btn-lg btn-block" type="submit" id="normal-import">Save</button>
                            </p>
                        </form>
                    </div>
                </div>
              </div>
          </div>
          <div class="col-md-6">
            <div class="row">
              <div class="col-md-12">
                  <div class="tile user-settings">
                      <h4 class="line-head">Admin Profile</h4>
                      <form action="<?php echo e(route('admin.settings.update')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-4">
                          <div class="col-md-6">
                            <label>Name</label>
                            <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" type="text" name="name" value="<?php echo e($user['name']); ?>" autocomplete="off" required>
                            <?php if($errors->has('name')): ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($errors->first('name')); ?></strong>
                              </span>
                            <?php endif; ?>
                          </div>    
                          <div class="clearfix"></div>
                          <div class="col-md-6">
                              <label>Email</label>
                              <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" autocomplete="off" type="email" name="email" value="<?php echo e($user['email']); ?>" required>
                              <?php if($errors->has('email')): ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($errors->first('email')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>                
                        </div>
                        <div class="row">                          
                          <div class="col-md-6 mb-4">
                            <label>Password</label>
                          <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" autocomplete="off" value="<?php echo e(old('password')); ?>" type="password" name="password">
                            <?php if($errors->has('password')): ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($errors->first('password')); ?></strong>
                              </span>
                            <?php endif; ?>
                          </div>
                          <div class="clearfix"></div>
                          <div class="col-md-6 mb-4">
                            <label>Confirm Password</label>
                            <input class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" type="password" name="password_confirmation" autocomplete="off" value="<?php echo e(old('password_confirmation')); ?>">
                            <?php if($errors->has('password_confirmation')): ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                              </span>
                            <?php endif; ?>
                          </div>
                          <div class="clearfix"></div>                          
                        </div>
                        <div class="row">
                          <div class="col-md-12">
                              <div class="form-group file1">
                                  <label class="control-label">Profile Photo</label>
                                  <input class="form-control<?php echo e($errors->has('photo') ? ' is-invalid' : ''); ?>" id="adminphoto" name="photo" type="file">
                                  <?php if($errors->has('photo')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('photo')); ?></strong>
                                    </span>
                                  <?php endif; ?>
                              </div>
                          </div>
                        </div>
                        <div class="row mb-10">
                          <div class="col-md-12">
                              <p class="bs-component">
                                  <button class="btn btn-primary btn-lg btn-block" type="submit" id="adminsave">Save</button>
                              </p>
                          </div>
                        </div>
                      </form>
                  </div>
              </div>
            </div>
          </div>
        </div>        
    </main>
  <?php $__env->stopSection(); ?>
  
  
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>